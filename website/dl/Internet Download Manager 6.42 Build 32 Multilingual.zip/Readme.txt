--------------------------------------------------------------------

1. Install the program. Don't start!
2. Run Patch file as Administrator and apply it (click on the "crack" button).
3. Enjoy!

--------------------------------------------------------------------
